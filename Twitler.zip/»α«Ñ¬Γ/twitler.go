package main
//Вадим
import (
	"database/sql"
	"fmt"
	"html/template"
	"log"
	"net/http"

	"github.com/gorilla/sessions"
	_ "modernc.org/sqlite"

)

var db *sql.DB
var store = sessions.NewCookieStore([]byte("super-secret-key")) // Секретный ключ для сессий

func init() {
	var err error
	db, err = sql.Open("sqlite", "./twitter_clone.db")
	if err != nil {
		log.Fatal(err)
	}
	createTables()
}

func createTables() {
	userTable := `
	CREATE TABLE IF NOT EXISTS users (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		username TEXT UNIQUE NOT NULL,
		password TEXT NOT NULL
	);
	`
	postTable := `
	CREATE TABLE IF NOT EXISTS posts (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		user_id INTEGER NOT NULL,
		content TEXT NOT NULL,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
		FOREIGN KEY (user_id) REFERENCES users(id)
	);
	`
	_, err := db.Exec(userTable)
	if err != nil {
		log.Fatal(err)
	}
	_, err = db.Exec(postTable)
	if err != nil {
		log.Fatal(err)
	}
}

// Шаблоны HTML
var templates = template.Must(template.ParseGlob("templates/*.html"))

// Структура для отображения постов
type Post struct {
	Username  string
	Content   string
	CreatedAt string
}

// Главная страница
func homeHandler(w http.ResponseWriter, r *http.Request) {
	session, _ := store.Get(r, "session")

	rows, err := db.Query(`
		SELECT users.username, posts.content, posts.created_at
		FROM posts
		INNER JOIN users ON posts.user_id = users.id
		ORDER BY posts.created_at DESC
	`)
	if err != nil {
		http.Error(w, "Error retrieving posts", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var posts []Post
	for rows.Next() {
		var post Post
		if err := rows.Scan(&post.Username, &post.Content, &post.CreatedAt); err != nil {
			http.Error(w, "Error reading posts", http.StatusInternalServerError)
			return
		}
		posts = append(posts, post)
	}

	data := struct {
		Posts      []Post
		IsLoggedIn bool
		Username   string
	}{
		Posts:      posts,
		IsLoggedIn: session.Values["username"] != nil,
		Username:   fmt.Sprintf("%v", session.Values["username"]),
	}

	templates.ExecuteTemplate(w, "home.html", data)
}

//Ин Со
// Регистрация
func registerPageHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet {
		templates.ExecuteTemplate(w, "register.html", nil)
		return
	}

	username := r.FormValue("username")
	password := r.FormValue("password")
	_, err := db.Exec("INSERT INTO users (username, password) VALUES (?, ?)", username, password)
	if err != nil {
		http.Error(w, "Error creating user", http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/login", http.StatusSeeOther)
}

// Авторизация
func loginPageHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet {
		templates.ExecuteTemplate(w, "login.html", nil)
		return
	}

	username := r.FormValue("username")
	password := r.FormValue("password")

	var userID int
	var storedPassword string
	err := db.QueryRow("SELECT id, password FROM users WHERE username = ?", username).Scan(&userID, &storedPassword)
	if err != nil || storedPassword != password {
		http.Error(w, "Invalid credentials", http.StatusUnauthorized)
		return
	}

	// Создаём сессию
	session, _ := store.Get(r, "session")
	session.Values["user_id"] = userID
	session.Values["username"] = username
	session.Save(r, w)

	http.Redirect(w, r, "/", http.StatusSeeOther)
}
//Ин Со
// Выход
func logoutHandler(w http.ResponseWriter, r *http.Request) {
	session, _ := store.Get(r, "session")
	session.Values = make(map[interface{}]interface{}) // Очищаем сессию
	session.Save(r, w)

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

//Ин Со
// Создание поста
func createPostHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	session, _ := store.Get(r, "session")
	userID, ok := session.Values["user_id"].(int)
	if !ok {
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	content := r.FormValue("content")
	_, err := db.Exec("INSERT INTO posts (user_id, content) VALUES (?, ?)", userID, content)
	if err != nil {
		http.Error(w, "Error creating post", http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func main() {
	http.HandleFunc("/", homeHandler)
	http.HandleFunc("/register", registerPageHandler)
	http.HandleFunc("/login", loginPageHandler)
	http.HandleFunc("/logout", logoutHandler)
	http.HandleFunc("/post", createPostHandler)

	// Статические файлы
	http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))

	fmt.Println("Server started at http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
